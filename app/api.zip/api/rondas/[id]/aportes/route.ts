import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { Decimal } from "@prisma/client/runtime/library";

type AporteLite = { socioId: number; monto: Decimal; multa: Decimal };
type AhorroAgg = { socioId: number; _sum: { monto: Decimal | null } };
type Context = { params: Promise<{ id: string; n: string }> };

export async function GET(_req: Request, context: Context) {
  const { params } = await context;
  const rondaId = Number((await params).id);
  const semana = Number((await params).n);

  const ronda = await prisma.ronda.findUnique({
    where: { id: rondaId },
    select: {
      id: true,
      nombre: true,
      semanaActual: true,
      montoAporte: true,
      ahorroObjetivoPorSocio: true,  // 👈 traer este campo
      participaciones: {
        select: {
          id: true,
          orden: true,
          socioId: true,
          socio: true,
        },
        orderBy: { orden: "asc" },
      }
    },
  });

  if (!ronda) return NextResponse.json({ error: "Ronda no encontrada" }, { status: 404 });

  // Aportes de la semana
  const aportes = (await prisma.aporte.findMany({
    where: { rondaId, semana },
    select: { socioId: true, monto: true, multa: true },
  })) as AporteLite[];

  // Ahorro acumulado hasta la semana actual (1..semana)
  const ahorroAgg = await prisma.ahorro.groupBy({
    by: ["socioId"],
    where: { rondaId, semana: { lte: semana } },
    _sum: { monto: true },
  });


  const ahorroBySocio: Record<number, Decimal> = {};
  for (const a of ahorroAgg) {
    ahorroBySocio[a.socioId] = a._sum.monto ?? new Decimal(0);
  }

  const aporteBySocio: Record<number, AporteLite> = {};
  for (const a of aportes) aporteBySocio[a.socioId] = a;

  const items = ronda.participaciones.map((p) => {
    const ap = aporteBySocio[p.socioId];
    const ah = ahorroBySocio[p.socioId] ?? new Decimal(0);

    const objetivo = new Decimal(ronda.ahorroObjetivoPorSocio ?? 0);
    const restante = objetivo.minus(ah);
    const restanteStr = (restante.lessThan(0) ? new Decimal(0) : restante).toString();

    return {
      participacionId: p.id,
      socioId: p.socioId,
      socio: {
        nombres: p.socio.nombres,
        apellidos: p.socio.apellidos,
        numeroCuenta: p.socio.numeroCuenta,
      },
      orden: p.orden,
      pagado: !!ap,
      monto: ap ? ap.monto.toString() : null,
      multa: ap ? ap.multa.toString() : "0",

      ahorroAcumulado: ah.toString(),     // 👈 NUEVO
      ahorroRestante: restanteStr,        // 👈 NUEVO
    };
  });

  return NextResponse.json({
    ronda: {
      id: ronda.id,
      nombre: ronda.nombre,
      semanaActual: ronda.semanaActual,
      montoAporte: ronda.montoAporte.toString(),
      ahorroObjetivoPorSocio: ronda.ahorroObjetivoPorSocio.toString(), // 👈 NUEVO
    },
    semana,
    totalParticipantes: ronda.participaciones.length,
    items,
  });
}

export async function POST(req: Request, context: Context) {
  const { params } = await context;
  const rondaId = Number((await params).id);

  const { socioId, semana, monto, multa } = await req.json();
  if (!socioId || !semana || monto == null) {
    return NextResponse.json({ error: "Faltan parámetros" }, { status: 400 });
  }

  // Verifica que la ronda exista
  const ronda = await prisma.ronda.findUnique({ where: { id: rondaId } });
  if (!ronda) return NextResponse.json({ error: "Ronda no encontrada" }, { status: 404 });

  // Crear aporte o reemplazar si ya existía
  const reg = await prisma.aporte.upsert({
    where: {
      rondaId_socioId_semana: {
        rondaId,
        socioId,
        semana,
      },
    },
    update: { monto, multa },
    create: { rondaId, socioId, semana, monto, multa },
  });

  return NextResponse.json({
    id: reg.id,
    socioId,
    semana,
    monto: reg.monto.toString(),
    multa: reg.multa.toString(),
  });
}
